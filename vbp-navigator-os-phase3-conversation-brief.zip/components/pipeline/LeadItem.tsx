"use client";

import { useState } from "react";
import Link from "next/link";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { Spinner } from "@/components/ui/Spinner";
import { CommentThread } from "@/components/collaboration/CommentThread";
import type { Lead, LeadStage } from "@/components/pipeline/types";
import { ASSESSMENT_QUESTIONS } from "@/lib/assessment-questions";
import { checkPmpEligibility } from "@/lib/pmp-eligibility";
import { buildConversationBrief, BRIEF_CONSUMED_KEYS } from "@/lib/conversation-brief";

const STAGE_ORDER: LeadStage[] = ["new", "contacted", "qualified", "won"];
const STAGE_TONE: Record<LeadStage, "neutral" | "accent" | "success" | "danger"> = {
  new: "neutral",
  contacted: "accent",
  qualified: "accent",
  won: "success",
  lost: "danger",
};
const STAGE_LABEL: Record<LeadStage, string> = {
  new: "New",
  contacted: "Contacted",
  qualified: "Qualified",
  won: "Won",
  lost: "Lost",
};

export function LeadItem({
  lead,
  serviceName,
  productName,
  onStageChange,
}: {
  lead: Lead;
  serviceName: string;
  productName: string | null;
  onStageChange: (stage: LeadStage) => void;
}) {
  const [error, setError] = useState("");
  const [pendingStage, setPendingStage] = useState<LeadStage | null>(null);
  const [wonCustomerId, setWonCustomerId] = useState<string | null>(null);

  async function setStage(stage: LeadStage) {
    setError("");
    setPendingStage(stage);
    try {
      const res = await fetch(`/api/leads/${lead.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ stage }),
      });
      if (res.ok) {
        const body: { customerId?: string | null } = await res.json().catch(() => ({}));
        if (body.customerId) setWonCustomerId(body.customerId);
        onStageChange(stage);
      } else {
        const body = await res.json().catch(() => ({}));
        setError(body.error || "Couldn't update stage");
      }
    } finally {
      setPendingStage(null);
    }
  }

  const nextStage = lead.stage === "lost" ? null : STAGE_ORDER[STAGE_ORDER.indexOf(lead.stage) + 1];

  // Post-Phase-G fix (Diallo: "if I view a Lead who came in via the
  // assessment... I'd wish to see the lead's assessment score, what
  // drives them, what challenges they're facing... real talking points
  // for a sales follow-up call"). Rendered from ASSESSMENT_QUESTIONS
  // (the same list /assess itself asks from) rather than raw object
  // keys, so this reads as "Years of experience: 3–5 years," not
  // "experience: 3-5 years" — and in the order the questions were
  // actually asked, not object-key order. Empty for any lead not
  // promoted from an /assess prospect (assessmentAnswers is then {}).
  //
  // Phase 3 fix: PMP_ELIGIBILITY_QUESTIONS (lib/pmp-eligibility.ts)
  // reuses the "motivation" key for its own supplementary question, so
  // a PMP lead's answers would otherwise leak one stray line into this
  // panel by pure key coincidence, duplicating what the PMP facts
  // panel and Conversation Brief already show with a better label.
  // isPmpAnswers below makes this panel and the PMP one mutually
  // exclusive, the same pattern ProspectItem.tsx already uses. On top
  // of that, any individual key Conversation Brief already shows above
  // (see lib/conversation-brief.ts's BRIEF_CONSUMED_KEYS) is filtered
  // out here too — not just for the PMP case, but for an old-style
  // generic-assessment lead as well, where "timing"/"motivation" would
  // otherwise duplicate the Brief panel's own reading of those same
  // two keys.
  const isPmpAnswers = !!lead.assessmentAnswers && "educationPathway" in lead.assessmentAnswers;
  const assessmentEntries = isPmpAnswers
    ? []
    : ASSESSMENT_QUESTIONS.filter((q) => !BRIEF_CONSUMED_KEYS.has(q.key))
        .map((q) => ({
          label: q.label,
          value: lead.assessmentAnswers?.[q.key],
        }))
        .filter((e) => e.value !== undefined && e.value !== null && e.value !== "");

  // Phase 2 — PMP eligibility, facts only. Recomputed live from the
  // stored assessmentAnswers (never persisted separately — see
  // lib/pmp-eligibility.ts) whenever this lead's answers came from the
  // PMP eligibility question set rather than the generic assessment
  // questions above (detected by the presence of educationPathway, a
  // key unique to the PMP question set — see lib/pmp-eligibility.ts).
  const pmpFacts = isPmpAnswers ? checkPmpEligibility(lead.assessmentAnswers) : null;
  // Phase 3 — Conversation Brief, same rules as ProspectItem.tsx:
  // built only from what was actually captured, never rendered empty.
  const brief = buildConversationBrief(lead.assessmentAnswers);

  return (
    <Card style={{ padding: "var(--v2-space-4)" }}>
      <div style={{ display: "flex", justifyContent: "space-between", gap: "var(--v2-space-3)", flexWrap: "wrap" }}>
        <div>
          <div style={{ fontWeight: 600 }}>{lead.contactName}</div>
          <div style={{ fontSize: "0.8rem", color: "var(--v2-text-faint)" }}>
            {serviceName}
            {lead.contactEmail ? ` · ${lead.contactEmail}` : ""}
            {lead.contactPhone ? ` · ${lead.contactPhone}` : ""}
          </div>
          {productName && (
            <div style={{ marginTop: 2 }}>
              <Badge tone="accent">{productName}</Badge>
            </div>
          )}
          {lead.notes && (
            <div style={{ fontSize: "0.8rem", color: "var(--v2-text-muted)", marginTop: 4, whiteSpace: "pre-wrap" }}>
              {lead.notes}
            </div>
          )}
        </div>
        <div style={{ display: "flex", gap: "var(--v2-space-2)", alignItems: "center" }}>
          <Badge tone={STAGE_TONE[lead.stage]}>{STAGE_LABEL[lead.stage]}</Badge>
          {nextStage && (
            <button
              type="button"
              onClick={() => setStage(nextStage)}
              disabled={pendingStage !== null}
              className={`v2-btn v2-btn-secondary ${pendingStage === nextStage ? "v2-btn-busy" : ""}`}
              style={{ padding: "4px 10px", fontSize: "0.75rem" }}
            >
              {pendingStage === nextStage && <Spinner size={11} />}
              {pendingStage === nextStage ? "Marking…" : `Mark ${STAGE_LABEL[nextStage].toLowerCase()}`}
            </button>
          )}
          {lead.stage !== "lost" && lead.stage !== "won" && (
            <button
              type="button"
              onClick={() => setStage("lost")}
              disabled={pendingStage !== null}
              className={`v2-btn v2-btn-secondary ${pendingStage === "lost" ? "v2-btn-busy" : ""}`}
              style={{ padding: "4px 10px", fontSize: "0.75rem" }}
            >
              {pendingStage === "lost" && <Spinner size={11} />}
              {pendingStage === "lost" ? "Marking…" : "Mark lost"}
            </button>
          )}
        </div>
      </div>
      {brief.hasContent && (
        <div
          style={{
            marginTop: "var(--v2-space-3)",
            padding: "var(--v2-space-3)",
            background: "var(--v2-surface-sunken)",
            border: "1px solid var(--v2-border)",
            borderRadius: "var(--v2-radius, 8px)",
          }}
        >
          <div style={{ fontSize: "0.7rem", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.03em", color: "var(--v2-text-faint)", marginBottom: 6 }}>
            Conversation Brief
          </div>
          <div style={{ display: "grid", gap: 4, fontSize: "0.82rem" }}>
            <div>
              <span style={{ color: "var(--v2-text-muted)" }}>Why they came: </span>
              <span style={{ color: "var(--v2-text)", fontWeight: 500 }}>{brief.whyTheyCame ?? "Not yet established"}</span>
            </div>
            <div>
              <span style={{ color: "var(--v2-text-muted)" }}>What they told us: </span>
              <span style={{ color: "var(--v2-text)", fontWeight: 500 }}>{brief.mainChallenge ?? "Not yet established"}</span>
            </div>
            <div>
              <span style={{ color: "var(--v2-text-muted)" }}>What they've tried: </span>
              <span style={{ color: "var(--v2-text)", fontWeight: 500 }}>{brief.whatTried ?? "Not yet established"}</span>
            </div>
            <div>
              <span style={{ color: "var(--v2-text-muted)" }}>Who this is for: </span>
              <span style={{ color: "var(--v2-text)", fontWeight: 500 }}>{brief.who ?? "Not yet established"}</span>
            </div>
            <div>
              <span style={{ color: "var(--v2-text-muted)" }}>Timing: </span>
              <span style={{ color: "var(--v2-text)", fontWeight: 500 }}>{brief.timing ?? "Not yet established"}</span>
            </div>
            {brief.categoryContext && (
              <div>
                <span style={{ color: "var(--v2-text-muted)" }}>Also noted: </span>
                <span style={{ color: "var(--v2-text)", fontWeight: 500 }}>{brief.categoryContext}</span>
              </div>
            )}
          </div>
        </div>
      )}
      {assessmentEntries.length > 0 && (
        <div
          style={{
            marginTop: "var(--v2-space-3)",
            padding: "var(--v2-space-3)",
            background: "var(--v2-surface-sunken)",
            border: "1px solid var(--v2-border)",
            borderRadius: "var(--v2-radius, 8px)",
          }}
        >
          <div style={{ fontSize: "0.7rem", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.03em", color: "var(--v2-text-faint)", marginBottom: 6 }}>
            Assessment — for the follow-up call
          </div>
          <div style={{ display: "grid", gap: 4 }}>
            {assessmentEntries.map(({ label, value }) => (
              <div key={label} style={{ fontSize: "0.82rem" }}>
                <span style={{ color: "var(--v2-text-muted)" }}>{label}: </span>
                <span style={{ color: "var(--v2-text)", fontWeight: 500 }}>{String(value)}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {pmpFacts && (
        <div
          style={{
            marginTop: "var(--v2-space-3)",
            padding: "var(--v2-space-3)",
            background: "var(--v2-surface-sunken)",
            border: "1px solid var(--v2-border)",
            borderRadius: "var(--v2-radius, 8px)",
          }}
        >
          <div style={{ fontSize: "0.7rem", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.03em", color: "var(--v2-text-faint)", marginBottom: 6 }}>
            PMP Eligibility — facts
          </div>
          <div style={{ display: "grid", gap: 4, fontSize: "0.82rem" }}>
            <div>
              <span style={{ color: "var(--v2-text-muted)" }}>Education pathway: </span>
              <span style={{ color: "var(--v2-text)", fontWeight: 500 }}>{pmpFacts.pathway ? pmpFacts.pathway.label : "Not specified"}</span>
            </div>
            <div>
              <span style={{ color: "var(--v2-text-muted)" }}>Reported experience: </span>
              <span style={{ color: "var(--v2-text)", fontWeight: 500 }}>
                {pmpFacts.reportedMonths !== null ? `${pmpFacts.reportedMonths} months` : "Not specified"}
                {pmpFacts.pathway ? ` (pathway requires ${pmpFacts.pathway.requiredMonths})` : ""}
              </span>
            </div>
            <div>
              <span style={{ color: "var(--v2-text-muted)" }}>Within 10-year window: </span>
              <span style={{ color: "var(--v2-text)", fontWeight: 500 }}>{pmpFacts.recency ?? "Not specified"}</span>
            </div>
            <div>
              <span style={{ color: "var(--v2-text-muted)" }}>Training: </span>
              <span style={{ color: "var(--v2-text)", fontWeight: 500 }}>{pmpFacts.training ?? "Not specified"}</span>
            </div>
          </div>
          <p style={{ fontSize: "0.8rem", fontWeight: 500, margin: "6px 0 0" }}>{pmpFacts.statement}</p>
        </div>
      )}

      {error && <p style={{ color: "var(--v2-danger)", fontSize: "0.8rem", margin: "8px 0 0" }}>{error}</p>}

      {/* v3.0 Phase 4: winning a lead also creates a Customer +
          Engagement (app/api/leads/[id]/route.ts), which returns the
          new customerId — deep-links straight to that customer's own
          workspace (Phase E's /customers/[id]) when this component was
          the one that just marked the lead won. wonCustomerId only
          lives in this component's local state (a Lead has no
          customerId of its own to reload), so a lead that was already
          won before this page load falls back to the plain Customers
          list, which now has an "Open" link to every customer's page. */}
      {lead.stage === "won" && (
        <p style={{ fontSize: "0.75rem", color: "var(--v2-text-faint)", margin: "8px 0 0" }}>
          → Customer record created — see{" "}
          <Link
            href={wonCustomerId ? `/customers/${wonCustomerId}` : "/customers"}
            style={{ color: "var(--v2-accent)" }}
          >
            {wonCustomerId ? "their Customer page" : "Customers"}
          </Link>
        </p>
      )}

      <CommentThread entityType="lead" entityId={lead.id} />
    </Card>
  );
}
