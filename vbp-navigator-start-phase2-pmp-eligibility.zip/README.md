# /start Warm Lead Intelligence — Phase 2 (PMP Eligibility, Facts Only)

Third piece of the `/start` warm-lead-intelligence build, after Phase 1 (intake backbone) and the invoice-reconciliation pass. Per Diallo's explicit decision (recorded 2026-09-19, project doc `vbp-navigator-os-start-warm-lead-intelligence-plan.md`): **no PMP Readiness score.** PMI doesn't publish one and GDC hasn't defined its own rubric — a number here would be false precision. This phase produces plain facts instead.

## What this phase does

Replaces the generic, admittedly-not-PMI four questions the Certification path was asking (`lib/assessment-questions.ts`'s own header comment already flagged this: "not a reproduction of PMI's actual PMP certification eligibility criteria — which this app has no source for") with PMI's real four eligibility inputs, verified directly against pmi.org, and a plain-language read of where the visitor stands against PMI's published pathways — shown back to the visitor immediately, and carried through unchanged to staff on the Prospect and Lead pages.

### PMI's real requirements (verified live against pmi.org on 2026-09-19, not from training data)

Four education/experience pathways, all requiring the qualifying experience to be within the last 10 years, plus 35 hours of project management education (an active CAPM certification satisfies this automatically):

| Education | Required experience |
|---|---|
| High school diploma / GED | 60 months (5 years) |
| Associate's degree or equivalent | 48 months (4 years) |
| Bachelor's degree or higher | 36 months (3 years) |
| Bachelor's/postgrad from a PMI GAC program | 24 months (2 years) |

### `lib/pmp-eligibility.ts` (new)

- `PMP_ELIGIBILITY_QUESTIONS` — the four real inputs: education pathway (select), months of experience (a new numeric field type, not a bucketed select — see below), experience recency (select), training/CAPM (select).
- `checkPmpEligibility(answers)` — a pure function, no I/O, called identically from the public form (client-side, right after the visitor answers) and from the staff-facing Lead/Prospect pages (recomputed live from the stored answers, never persisted separately — one source of truth, nothing to drift). Returns the matched pathway, the reported experience against that pathway's minimum, recency and training as-reported, and a plain statement — always one of "appears to align," a named shortfall ("below the 36-month minimum"), a recency concern, a training gap, or "not enough information yet" when anything is unanswered. Never a score, percentage, or "readiness" field — verified by an explicit assertion in the test suite below.
- `isPmpProduct(name)` — a deliberately narrow, catalog-read signal (does the product name mention PMP?), not a new catalog field. GDC's real catalog has exactly one Certification Program item today; a future non-PMP certification would need its own eligibility framework entirely, and this narrow naming keeps that seam visible rather than silently misapplying PMI's PMP-specific rules to something else.

### `lib/assessment-questions.ts`

`AssessmentQuestion.type` gains `"number"` alongside `"select"`/`"text"` — months of experience is asked as an exact number, not a bucketed range, since a pathway's requirement is an exact month count and a bucket would either lose precision or (worse) require picking arbitrary bucket edges that happen to line up with PMI's thresholds. `QuestionField` in `StartForm.tsx` renders it as a real number input.

### `components/public/StartForm.tsx`

A Certification item whose name matches `isPmpProduct` now asks `PMP_ELIGIBILITY_QUESTIONS` instead of the old generic four; any other Certification item (none exist in GDC's catalog today, but the app stays catalog-driven rather than hardcoded to PMP) still gets the original questions unchanged. The success screen — the "give something useful back" moment from the spec — now shows a **PMP Eligibility Check** panel built from the visitor's own answers: pathway, reported experience against the requirement, recency, training, the plain statement, and a disclaimer that this isn't an official PMI determination.

### `components/pipeline/LeadItem.tsx` / `components/prospects/ProspectItem.tsx`

Both now detect PMP answers (presence of the `educationPathway` key, unique to the PMP question set) and render the identical **PMP Eligibility — Facts** panel — on the Prospect page before promotion, and again on the Lead page after, since a promoted Lead carries the same stored answers forward untouched. Verified end-to-end: a Prospect's facts panel is byte-identical to what the same Prospect shows after being promoted to a Lead. `ProspectItem.tsx`'s existing raw key:value answer dump still applies for anything that isn't PMP (a non-PMP certification, or a general-discovery lead) — nothing lost there, just not duplicated for PMP.

## Not a schema change

Everything still lands in `prospects.assessment_answers` / `leads.assessment_answers`, the same flexible jsonb column used since before this phase. No migration.

## Apply

Copy all five files into their matching paths. No migration, no env var changes, no other files touched.

## Verified before packaging

- `npx tsc --noEmit` and `npm run build` both clean.
- **24 unit assertions** against `checkPmpEligibility` directly: all four pathways confirmed to pass at exactly their required month count; one month short of a pathway's minimum confirmed to fail with the exact shortfall named; an active CAPM confirmed to satisfy the training requirement on its own; a "No" recency answer confirmed to fail eligibility even with more than enough months (recency isn't waived by experience); a "partial" recency answer confirmed to produce a genuinely non-committal statement rather than a false pass or fail; missing answers confirmed to produce an honest "not enough information yet" rather than a guess; and an explicit check that the result shape never contains a `score`, `readiness`, or `percentage` field anywhere.
- **6 assertions** against a freshly reset local database via the real HTTP API: a PMP item and a non-PMP certification item (Six Sigma) seeded; an eligible submission, a below-minimum submission, and a non-PMP submission all accepted; PMP answers confirmed round-tripping through `/api/prospects` intact.
- Playwright screenshots: the PMP eligibility question form (all four real PMI inputs, numeric experience field); the filled form; the visitor-facing "PMP Eligibility Check" success panel (facts, statement, disclaimer — no score); the staff Prospects page showing the PMP facts panel for two PMP prospects side-by-side with the Six Sigma prospect correctly falling back to the generic raw-answer view; and the same prospect after promotion, confirming the identical facts panel now appears on the Lead card in Pipeline.
- Full route regression sweep across 18 routes — all `200` except the two `/apply`/`/assess` redirect stubs at their expected `307`.
- All five files diffed byte-for-byte against the source tree before packaging.

## Not done yet / carried forward

Still ahead, in order, per the plan doc:
- Phase 3 — Conversation Brief + a real Task created on promotion, on the Lead page.
- Phase 4 — existing-customer detection moved from promotion-time to `/start` submission-time.
- Phase 5 — the post-conversion opportunity engine (Engagement-completed, invoice-paid, class-completed, and organization-level grouping triggers) — unblocked since the invoice-reconciliation pass.
- Phase 6 — card-based visual pass across the Customer/Lead pages, and the "Room to grow with [Name]" copy rewrite on the Customer page's suggestions section.
