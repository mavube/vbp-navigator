# VBP Navigator OS — Phase 11: Views & navigation (Cluster D)

v3.0 roadmap, Cluster D from `claude/vbp-navigator-os-v3-enhancement-backlog.md`. Full detail (design calls, what was verified, what's carried forward) is in the "v3.0 roadmap — Phase 11: Views & navigation (Cluster D)" entry of `claude/vbp-navigator-os-v2-build-guide.md`, synced to the project. This README is the short version for applying the files.

## What this ships

- **Task priority** — a new `low`/`normal`/`high`/`urgent` field on every task, color-coded across List/Kanban/Gantt.
- **Kanban** — native drag-and-drop between columns, group by service/assignee, filter by assignee, priority colors, and an inline error banner when a status change is rejected (e.g. blocked by an unfinished dependency) — closes a gap Phase 9's build guide had explicitly flagged as belonging here.
- **Gantt** — swimlanes (grouped by service), a Month/Week zoom toggle, and drag-to-reschedule (drag a bar left/right, both dates shift together).
- **Calendar** — click any day to quick-add a task due that day, class-session chips alongside task chips, and a task-detail modal that shows a blocked task's open blockers (owner/impact/required action) inline.
- **Sidebar** — collapsible on desktop (persisted per-browser), badge counts (overdue tasks, high-impact blockers), and a live identity block.
- **Topbar** — new, desktop-only: global search across services/tasks/leads/classes/customers/prospects, a quick-add menu, a notifications bell, the dark-mode toggle (moved here from the sidebar), and identity + sign-out. Mobile keeps its existing hamburger bar unchanged — this is additive, not a replacement.

## Apply

1. Run the new migration against Supabase: `supabase/migrations/0018_phase11_views_navigation.sql` (adds `tasks.priority`).
2. Copy every file in this package into the matching path in the repo, overwriting what's there. Everything here is either a modified existing file or a genuinely new one — nothing needs deleting.
3. `npm install` isn't needed — no new dependencies this phase.
4. `npm run build` to confirm, then deploy as usual (Vercel auto-deploys on push).

## Verified before packaging

- `npx tsc --noEmit` and `npm run build` both clean.
- 23-assertion API-level smoke test, 23/23 passing against a fresh local SQLite database.
- Playwright screenshots at 1440px and 390px across every view (List/Kanban/Gantt/Calendar, default and interacted states) and the Topbar — no horizontal overflow at either width.
- Every file in this package diffed byte-for-byte against the source tree before zipping.

## Files in this package (23)

```
supabase/migrations/0018_phase11_views_navigation.sql

lib/db-tasks.ts
lib/identity.ts          (new)
lib/search.ts            (new)

app/api/tasks/route.ts
app/api/tasks/[id]/route.ts
app/api/me/route.ts              (new)
app/api/search/route.ts          (new)
app/api/notifications/route.ts   (new)

components/tasks/types.ts
components/tasks/priority.ts     (new)
components/tasks/NewTaskForm.tsx
components/tasks/TaskItem.tsx
components/tasks/TaskKanban.tsx
components/tasks/TaskGantt.tsx
components/tasks/TaskCalendar.tsx
components/tasks/TaskBoard.tsx

components/ui/navConfig.ts       (new)
components/ui/Sidebar.tsx
components/ui/Topbar.tsx         (new)
components/ui/AppShell.tsx
components/ui/icons.tsx

styles/components.css
```

## Not done yet / carried forward

- Global search is a simple in-process substring filter, not a real search index — fine at current data volume.
- Topbar's quick-add links to each module's existing create form rather than an inline modal — no shared modal-form infrastructure exists for six-plus entity shapes yet.
- No dark-mode visual QA specifically on the new Topbar/collapsed-sidebar/Kanban-drag/Gantt-swimlane CSS.
- Cluster E (AI Advisor expansion) is next, in the same session per Diallo's explicit phasing choice.
