import type { Metadata, Viewport } from "next";
import "./globals.css";
import "@/styles/design-tokens.css";
import "@/styles/components.css";
import { ServiceWorkerRegister } from "@/components/ServiceWorkerRegister";
import { VersionBadge } from "@/components/ui/VersionBadge";
import { AppShell } from "@/components/ui/AppShell";

export const metadata: Metadata = {
  title: "VBP Navigator OS",
  description:
    "Service management on the ValueBlueprint® method — Service & Value Architecture, tasks, pipeline, budget, and more.",
  manifest: "/manifest.json",
  icons: { icon: "/icons/icon-192.png", apple: "/icons/icon-192.png" },
};

export const viewport: Viewport = {
  themeColor: "#2563EB",
  viewportFit: "cover",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>
        {/* Applies a saved dark/light choice (see components/ui/ThemeToggle.tsx)
            before first paint, so a returning visitor never sees a flash of
            the wrong theme. Inline + synchronous + first in <body> on
            purpose: this runs before the rest of the page is parsed. With no
            saved choice, this is a no-op and the CSS's own
            prefers-color-scheme handling (styles/design-tokens.css) governs,
            same as before this phase. */}
        <script
          dangerouslySetInnerHTML={{
            __html: `(function(){try{var t=localStorage.getItem("vbp-theme");if(t==="light"||t==="dark"){document.documentElement.setAttribute("data-theme",t);}}catch(e){}})();`,
          }}
        />
        <AppShell>{children}</AppShell>
        <VersionBadge />
        <ServiceWorkerRegister />
      </body>
    </html>
  );
}
